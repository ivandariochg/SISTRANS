package vos;

public class Devolucion {
		
	int id;
	
	Compra boleta;

	public Compra getBoleta() {
		return boleta;
	}

	public void setBoleta(Compra boleta) {
		this.boleta = boleta;
	}
	
	

}
